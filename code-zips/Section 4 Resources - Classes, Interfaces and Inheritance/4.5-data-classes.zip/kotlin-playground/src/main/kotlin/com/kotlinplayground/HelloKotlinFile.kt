package com.kotlinplayground



fun main(){

    println("Hello Kotlin!")

}