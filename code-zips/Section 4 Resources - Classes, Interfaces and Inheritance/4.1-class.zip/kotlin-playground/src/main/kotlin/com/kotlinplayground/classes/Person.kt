package com.kotlinplayground.classes

class Person {

    fun action(){
        println("Person Walks")
    }
}

fun main() {
    val person = Person()
    person.action()
}