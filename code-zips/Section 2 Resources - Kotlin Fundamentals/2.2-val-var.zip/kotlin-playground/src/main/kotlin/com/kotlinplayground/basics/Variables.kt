package com.kotlinplayground.basics

fun main() {

    val name : String = "Dilip"
    println(name)

    //name = "Dilip1"

    var age : Int = 34
    println(age)
    age = 35
    println(age)

}

