package com.kotlinplayground

class HelloKotlin {
}

fun main() {

    println("Hello Kotlin!")

}