package com.kotlinspring.dto

data class CourseDTO(
    val id : Int?,
    val name : String,
    val category : String
)