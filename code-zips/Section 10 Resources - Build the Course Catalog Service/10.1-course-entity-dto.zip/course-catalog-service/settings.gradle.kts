rootProject.name = "course-catalog-service"
